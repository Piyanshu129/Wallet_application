package model;

public enum TransactionType {
	DEBIT,CREDIT;
}
