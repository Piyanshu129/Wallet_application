package model;

public enum AccountType {
	SAVINGS,CURRENT,SALARY,RD,FD,LOAN,LAP;
}
