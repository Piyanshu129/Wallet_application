package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;


import dto.TransactionDepositDTO;
import model.Account;
import model.AccountType;
import model.Address;
import model.Customer;
import model.Gender;
import model.Transaction;
import model.TransactionType;

public class DBHandler {

	public int getId(String tblName,String colName)
	{
		int res=0;
		
		try {
			
			 Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

			PreparedStatement stmt=con.prepareStatement("select max("+colName+") as res from "+ tblName);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{
				res=rset.getInt("res");
				res=res+1;
			}
			else
			{
				res=1;
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	
	
	
	
	public Address saveAddress(Address add)
	{
		Address a=null;
		
		try {
			
		Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");
			PreparedStatement stmt=con.prepareStatement("insert into address values (?,?,?,?,?,?)");
			stmt.setInt(1, add.getAddressId());
			stmt.setString(2, add.getAddressLine1());
			stmt.setString(3, add.getAddressLine2());
			stmt.setString(4, add.getCity());
			stmt.setString(5, add.getState());
			stmt.setString(6, add.getPincode());
			int res=stmt.executeUpdate();
			if(res==0)
			{
				a=null;
			}
			else
			{
				a=add;
				System.out.println("address saved successfully");
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	
	
	
	
	
	
	
	public Customer saveCustomer(Customer cust) {
	    Customer c = null;
	    
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");
	        PreparedStatement stmt = con.prepareStatement("insert into customer values (?,?,?,?,?,?,?,?,?)");
	        stmt.setInt(1, cust.getCustomerId());
	        stmt.setString(2, cust.getFirstName());
	        stmt.setString(3, cust.getLastName());
	        stmt.setString(4, cust.getEmailId());
	        stmt.setString(5, cust.getContactNo());
	        stmt.setInt(6, cust.getAddress().getAddressId());
	        String strGender = (cust.getGender() == Gender.MALE) ? "Male" : "Female";
	        stmt.setString(7, strGender);
	        stmt.setString(8, cust.getPassword());
	       
	        //Customer c1=new Customer();
	        //c1.setCustomerId(cust.getCustomerId());
	        
	        // Format the registration date string to 'YYYY-MM-DD'
	        LocalDate regDate = cust.getRegisterationDate();
	        String formattedRegDate = regDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
	        stmt.setString(9, formattedRegDate);
	        
	        int res = stmt.executeUpdate();
	        con.close();
	        
	        if (res == 0) {
	            c = null;
	        } else {
	            System.out.println("Customer registered successfully");
	            c = cust;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    
	    return c;
	}




	
	



	public boolean isValidCustByEmailidAndPwd(String strEmailId, String strPwd) {
		boolean res=false;
		
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");
			PreparedStatement stmt=con.prepareStatement("select * from customer where emailid=? and pwd=?");
			stmt.setString(1, strEmailId);
			stmt.setString(2, strPwd);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{
				res=true;
			}
			else
			{
				res=false;
			}
			System.out.println("is valid customer");
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}



	
	




	public Customer getCustomerByEmailidAndPwd(String strEmailId) {
	    Customer cust = null;

	    PreparedStatement stmt;
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

	        stmt = con.prepareStatement("select * from customer where emailid=?");
	        stmt.setString(1, strEmailId);

	        ResultSet rset = stmt.executeQuery();
	        if (rset.next()) {
	            int customerId = rset.getInt("customerId");
	            String firstName = rset.getString("firstName");
	            String lastName = rset.getString("lastName");
	            String emailId = rset.getString("emailid");
	            String contactNo = rset.getString("contactNo");
	            int addressId = rset.getInt("addressId");
	            Address address = getAddressByAddressId(addressId);
	            String strGender = rset.getString("gender");
	            Gender gender;
	            if (strGender.equals(Gender.MALE)) {
	                gender = Gender.MALE;

	            } else {
	                gender = Gender.FEMALE;
	            }
	            String password = rset.getString("pwd");
	            String confirmPassword = "";
	            String strRegDate = rset.getString("registerationDate");

	          
	            LocalDate registrationDate = LocalDate.parse(strRegDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

	            cust = new Customer(customerId, firstName, lastName, emailId, contactNo, address, gender, password, confirmPassword, registrationDate);

	            System.out.println(cust);
	        }
	        con.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return cust;
	}

	
	public Address getAddressByAddressId(int addressId)
	{
		Address add=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");
		
			PreparedStatement stmt=con.prepareStatement("select * from Address where addressId=?");
			stmt.setInt(1, addressId);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{
				
				String addressLine1=rset.getString("addressLine1");
				String addressLine2=rset.getString("addressLine2");
				String city=rset.getString("city");
				String state=rset.getString("state");
				String pincode=rset.getString("pincode");
				add=new Address(addressId, addressLine1, addressLine2, city, state, pincode);
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return add;
	}
	


	
	
	

	
	
	
	
	
	public Customer getCustomerByCustId(String strCustId)
	{
		Customer cust=null;
		
		PreparedStatement stmt;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");
		
			stmt = con.prepareStatement("select * from customer where customerId=?");
			stmt.setString(1, strCustId);
			
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{
				int customerId=rset.getInt("customerId");
				String firstName=rset.getString("firstName");
				String lastName=rset.getString("lastName");
				String emailId=rset.getString("emailid");
				String contactNo=rset.getString("contactNo");
				int addressId=rset.getInt("addressId");
				Address address=getAddressByAddressId(addressId);
				
				String strGender=rset.getString("gender");
				 Gender gender;
				 if(strGender.equals(Gender.MALE))
				 {
					 gender=Gender.MALE;
							 
				 }
				 else
				 {
					 gender=Gender.FEMALE;
				 }
				String password=rset.getString("pwd");
				String confirmPassword="";
				String strRegDate=rset.getString("registerationDate");
				
			
				
				 LocalDate registerationDate=LocalDate.parse(strRegDate,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				 cust=new Customer(customerId, firstName, lastName, emailId, contactNo, address, gender, password, confirmPassword, registerationDate);
				 
				 //System.out.println(cust);
				 		 
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cust;
		
	}







	public Account saveAccount(Account acc) {
	    Account a = null;

	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

	        PreparedStatement stmt = con.prepareStatement("INSERT INTO account VALUES (?, ?, ?, ?, ?, ?)");
	        stmt.setInt(1, acc.getAccountNumber());
	        stmt.setInt(2, acc.getCustomer().getCustomerId());
	        stmt.setString(3, acc.getAccountType().toString()); 
	        stmt.setDouble(4, acc.getOpeningBalance());
	        stmt.setString(5, acc.getDescription());
	        stmt.setDate(6, java.sql.Date.valueOf(acc.getOpeningDate())); // Convert LocalDate to java.sql.Date

	        int res = stmt.executeUpdate();
	        if (res == 1) {
	            a = acc;
	            System.out.println("Account saved successfully");
	        } else {
	            System.out.println("Failed to save account");
	        }
	        con.close();
	    } catch (SQLException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return a;
	}
	
	
	
	public List<Account> getAccountsByCustId(String strCustId)
	{
		List<Account> lst=new LinkedList<Account>();
		
		try {
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

			PreparedStatement stmt=con.prepareStatement("select * from account where customerId=?");
			stmt.setString(1, strCustId);
			ResultSet rset=stmt.executeQuery();
			while(rset.next())
			{
				 int accountNumber=rset.getInt("accountNumber");
				 Customer customer=getCustomerByCustId(strCustId);
				 String strAccType=rset.getString("accountType");
				 AccountType accountType=null;
				 switch(strAccType)
					{
					case "SAVINGS":
						accountType=AccountType.SAVINGS;
						break;
					case "CURRENT":
						accountType=AccountType.CURRENT;
						break;
					case "SALARY":
						accountType=AccountType.SALARY;
						break;
					case "RD":
						accountType=AccountType.RD;
						break;
					case "FD":
						accountType=AccountType.FD;
						break;
					case "LOAN":
						accountType=AccountType.LOAN;
						break;
					}
				
				 double openingBalance=rset.getDouble("openingBalance");
				 LocalDate   openingDate;//openingDate
					String strOpeningDate=rset.getString("openingDate");
					
					//System.out.println(strOpeningDate);
					
					openingDate=LocalDate.parse(strOpeningDate,DateTimeFormatter.ofPattern("yyyy-MM-dd"));

					 
				String description=rset.getString("description");
				Account acc=new Account(accountNumber, customer, accountType, openingBalance, openingDate, description);
				lst.add(acc);
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
	}

	
	
	public Transaction depositAmountInAccount(TransactionDepositDTO tdd)
	{
 
		int accountNumber=tdd.getAccountNumber();
		Account acc=getAccountByAccNumber(accountNumber);
		double newOpeningBalance=acc.getOpeningBalance()+tdd.getAmount();
		updateOpeningBalanceByAccountNumber(tdd.getAccountNumber(), newOpeningBalance);
		
		int transactionId=getId("transaction", "transactionId");
		TransactionType transactionType=TransactionType.CREDIT;
		LocalDate transactionDate=LocalDate.now();
		System.out.println("todays date is "+ transactionDate.toString());
		 double amount=tdd.getAmount();
		 String description=tdd.getDescription();
		 Account fromAccount=getAccountByAccNumber(tdd.getFromAccountNumber());
		 Account toAccount=acc;
		
		Transaction trans=new Transaction(transactionId, transactionType, transactionDate, amount, description, fromAccount, toAccount);
		Transaction obj= saveTransaction(trans);
		System.out.println("transaction saved successfully");
		return obj;
	}
	
	
	public Account getAccountByAccNumber(int accountNumber)
	{
		Account acc=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

			PreparedStatement stmt=con.prepareStatement("select * from account where accountNumber=?");
			stmt.setInt(1, accountNumber);
			ResultSet rset=stmt.executeQuery();
			if(rset.next())
			{

				int customerId=rset.getInt("customerId");
				 String strAccType=rset.getString("accountType");
				 AccountType accountType=null;
				 switch(strAccType)
					{
					case "SAVINGS":
						accountType=AccountType.SAVINGS;
						break;
					case "CURRENT":
						accountType=AccountType.CURRENT;
						break;
					case "SALARY":
						accountType=AccountType.SALARY;
						break;
					case "RD":
						accountType=AccountType.RD;
						break;
					case "FD":
						accountType=AccountType.FD;
						break;
					case "LOAN":
						accountType=AccountType.LOAN;
						break;
					}
				
				 double openingBalance=rset.getDouble("openingBalance");
				 LocalDate   openingDate;//openingDate
					String strOpeningDate=rset.getString("openingDate");
					
					System.out.println(strOpeningDate);
					
					openingDate=LocalDate.parse(strOpeningDate,DateTimeFormatter.ofPattern("yyyy-MM-dd"));

					 
				String description=rset.getString("description");
				Customer customer=getCustomerByCustId(String.valueOf(customerId));
				acc=new Account(accountNumber, customer, accountType, openingBalance, openingDate, description);
				
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return acc;
	}

	
	
	
	public int updateOpeningBalanceByAccountNumber(int accountNumber,double newOpeningBalance)
	{
		int res=0;
	
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

			PreparedStatement stmt=con.prepareStatement("update account set openingBalance=? where accountNumber=?");
			stmt.setDouble(1, newOpeningBalance);
			stmt.setInt(2, accountNumber);
			res=stmt.executeUpdate();
			
			//System.out.println("update balance is now "+ newOpeningBalance +" accno is "+ accountNumber);
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	
	
	
	
	public Transaction saveTransaction(Transaction trans) {
	    Transaction t = null;

	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet_app", "root", "saini_dev79");

	        PreparedStatement stmt = con.prepareStatement("insert into transaction values (?,?,?,?,?,?,?)");
	        stmt.setInt(1, trans.getTransactionId());
	        String transactionType = (trans.getTransactionType() == TransactionType.CREDIT) ? "CREDIT" : "DEBIT";
	        stmt.setString(2, transactionType);
	        // Using java.sql.Date for handling dates
	        stmt.setDate(3, java.sql.Date.valueOf(trans.getTransactionDate()));
	        stmt.setDouble(4, trans.getAmount());
	        stmt.setString(5, trans.getDescription());
	        stmt.setInt(6, trans.getFromAccount().getAccountNumber());
	        stmt.setInt(7, trans.getToAccount().getAccountNumber());

	        int res = stmt.executeUpdate();
	        if (res == 0) {
	            t = null;
	        } else {
	            t = trans;
	            System.out.println("Transaction saved successfully");
	        }
	        con.close();
	    } catch (SQLException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return t;
	}
	
	
	
	
	
	
	

	


	public Transaction fundTransferFunction(TransactionDepositDTO tdd)
	{
		
		int fromAccountNumber=tdd.getFromAccountNumber();//2
		int toAccountNumber=tdd.getAccountNumber();//1
		Account fromAcc=getAccountByAccNumber(fromAccountNumber);
		System.out.println("Fund Transfer fromAcc=: "+fromAcc);
		Account toAcc=getAccountByAccNumber(toAccountNumber);
		System.out.println("Fund Transfer toAcc=: "+toAcc);
		
		
		double oldOpeningBalFromAccout=fromAcc.getOpeningBalance();
		double newOpeningBalFromAcc=oldOpeningBalFromAccout-tdd.getAmount();
		System.out.println("fund Transfer fromAccountNumber: "+fromAccountNumber+" newOpeningBalFromAcc="+newOpeningBalFromAcc);
		updateOpeningBalanceByAccountNumber(fromAccountNumber, newOpeningBalFromAcc);
		
		
	
		int transactionId=getId("transaction", "transactionId");
		TransactionType transactionType=TransactionType.CREDIT;
		LocalDate transactionDate=LocalDate.now();
		System.out.println("todays date is "+ transactionDate.toString());
		String description=tdd.getDescription();
		
		Transaction trans=new Transaction(transactionId, transactionType, transactionDate, tdd.getAmount(), description, fromAcc, toAcc);
		Transaction obj= saveTransaction(trans);
		
		
		 transactionId=getId("transaction", "transactionId");
		 transactionType=TransactionType.DEBIT;
		double oldOpeningBalToAcc=toAcc.getOpeningBalance();
		double newOpeningBalToAcc=oldOpeningBalToAcc+tdd.getAmount();
		updateOpeningBalanceByAccountNumber(toAccountNumber, newOpeningBalToAcc);

		


		
		


		trans=new Transaction(transactionId, transactionType, transactionDate, tdd.getAmount(), description,  fromAcc,toAcc);
		obj= saveTransaction(trans);
		
		
	
		
		
		
		System.out.println("transaction saved successfully");
		return obj;
	}

	
	
	
	
	
	
	
	
	public Transaction WithDrawAmountfromAccount(TransactionDepositDTO tdd)
	{
		
		int accountNumber=tdd.getAccountNumber();
		Account acc=getAccountByAccNumber(accountNumber);
		double newOpeningBalance=acc.getOpeningBalance()-tdd.getAmount();
		updateOpeningBalanceByAccountNumber(tdd.getAccountNumber(), newOpeningBalance);
		//2- save in transaction table
		int transactionId=getId("transaction", "transactionId");
		TransactionType transactionType=TransactionType.DEBIT;
		LocalDate transactionDate=LocalDate.now();
		//System.out.println("todays date is "+ transactionDate.toString());
		 double amount=tdd.getAmount();
		 String description=tdd.getDescription();
		 Account fromAccount=getAccountByAccNumber(tdd.getFromAccountNumber());
		 Account toAccount=acc;
		
		Transaction trans=new Transaction(transactionId, transactionType, transactionDate, amount, description, fromAccount, toAccount);
		Transaction obj= saveTransaction(trans);
		System.out.println("transaction saved successfully");
		return obj;
	}
}
