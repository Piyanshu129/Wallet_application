package dto;



public class TransactionDepositDTO {

	int customerId;
	int accountNumber;
	double amount;
	String description;
	int fromAccountNumber;
	
	
	
	public TransactionDepositDTO() {
		super();
	}
	public TransactionDepositDTO(int customerId, int accountNumber, double amount, String description,
			int fromAccountNumber) {
		super();
		this.customerId = customerId;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.description = description;
		this.fromAccountNumber = fromAccountNumber;
	}
	@Override 
	public String toString() {
		return "TransactionDepositDTO [customerId=" + customerId + ", accountNumber=" + accountNumber + ", amount="
				+ amount + ", description=" + description + ", fromAccountNumber=" + fromAccountNumber + "]";
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getFromAccountNumber() {
		return fromAccountNumber;
	}
	public void setFromAccountNumber(int fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}
	
	
}
