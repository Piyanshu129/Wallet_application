package controller;
import java.io.IOException;

import db.DBHandler;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Customer;

/**
 * Servlet implementation class Auth
 */
@WebServlet("/Auth")
public class Auth extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String strEmail,strPwd;
		strEmail=request.getParameter("txtEmail");
		strPwd=request.getParameter("txtPwd");
		DBHandler objDH=new DBHandler();
		boolean res=objDH.isValidCustByEmailidAndPwd(strEmail, strPwd);
		System.out.println("above");
		if(res==true)
		{
			System.out.println("below");
			HttpSession session=request.getSession();
			session.setAttribute("ssnEmail", strEmail);
			Customer cust=objDH.getCustomerByEmailidAndPwd(strEmail);
			session.setAttribute("ssnCustId", cust.getCustomerId());
			
			response.sendRedirect(request.getContextPath()+"/WelcomePage.jsp");
		}
		else
		{
			response.sendRedirect(request.getContextPath()+"/ErrorPage.jsp");
		}
				
	}

}