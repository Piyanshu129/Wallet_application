package controller;


import java.io.IOException;

import db.DBHandler;
import dto.TransactionDepositDTO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Transaction;

/**
 * Servlet implementation class FundTransfer
 */
@WebServlet("/FundTransfer")
public class FundTransfer extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		int customerId=Integer.parseInt(request.getParameter("txtCustid"));
		int toAaccountNumber=Integer.parseInt(request.getParameter("selAccountNo"));
		double amount=Double.parseDouble(request.getParameter("txtAmount"));
		String description=request.getParameter("txtDesc");
		int fromAccountNumber=Integer.parseInt(request.getParameter("selfromAcc"));
		
		TransactionDepositDTO tdd=new TransactionDepositDTO(customerId, toAaccountNumber, amount, description, fromAccountNumber);
		
		//System.out.println("fund transfer : "+ tdd);
		DBHandler objDH=new DBHandler();
		
		Transaction trans=objDH.fundTransferFunction(tdd);
		request.setAttribute("trans", trans);
		RequestDispatcher rd=request.getRequestDispatcher("FundTransfer.jsp");
		rd.forward(request, response);
	}

}
