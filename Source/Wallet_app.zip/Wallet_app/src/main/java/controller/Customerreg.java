package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import model.Address;
import model.Customer;
import model.Gender;

import db.DBHandler;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Customerreg")
public class Customerreg extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        int customerId = Integer.parseInt(request.getParameter("txtCustid"));
        String firstName = request.getParameter("txtFnm");
        String lastName = request.getParameter("txtLnm");
        String emailId = request.getParameter("txtEmailId");
        String contactNo = request.getParameter("txtContactNo");
        
        
        Address address;
        DBHandler objDH = new DBHandler();
        int addressId = objDH.getId("Address", "addressid");
        String addressLine1 = request.getParameter("txtAddressLine1");
        String addressLine2 = request.getParameter("txtAddressLine2");
        String city = request.getParameter("txtCity");
        String state = request.getParameter("txtState");
        String pincode = request.getParameter("txtPincode");
        
       
        Gender gender;
        String strGender = request.getParameter("rdbGender");
        if (strGender.equals("Male")) {
            gender = Gender.MALE;
        } else {
            gender = Gender.FEMALE;
        }
        
        
        String password = request.getParameter("txtPassword");
        String confirmPassword = "";
        String strRegDate = request.getParameter("txtRegDate");
        
      
        LocalDate registrationDate = LocalDate.parse(strRegDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

       
        address = new Address(addressId, addressLine1, addressLine2, city, state, pincode);
        
       
        objDH.saveAddress(address);
        
        
        Customer cust = new Customer(customerId, firstName, lastName, emailId, contactNo, address, gender, password, confirmPassword, registrationDate);
        
       
        cust = objDH.saveCustomer(cust);
        
        
        request.setAttribute("cust", cust);
        RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
        rd.forward(request, response);
    }
}
